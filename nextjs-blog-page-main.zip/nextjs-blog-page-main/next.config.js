module.exports = {
  images: {
    domains: ["images.ctfassets.net"],
  },
  i18n: {
    locales: ["en"],
    defaultLocale: "en",
  },
};
